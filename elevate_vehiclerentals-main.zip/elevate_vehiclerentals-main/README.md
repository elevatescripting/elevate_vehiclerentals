# elevate_vehiclerentals
Simple Vehicle Rental Script Compatible With ESX, QBCore, And QBOX 

## Dependencys ##
ox_lib

## How To Add ##

Simply Change The Vector On Where You Want Your Ped To Be -- You Can Change The Prices Of The Cars And Change What Cars You Would Like To Have In Your Rental
