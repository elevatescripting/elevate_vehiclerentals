
fx_version 'cerulean'
game 'gta5'

author 'Elevate Scripts'
description 'Advanced Vehicle Rental (ESX/QB/QBOX Compatible)'
version '2.0.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts { 'client.lua' }
server_scripts { 'server.lua' }
