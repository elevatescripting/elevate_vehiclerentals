
local function getFramework()
    if Config.Framework == 'esx' then
        return exports['es_extended']:getSharedObject()
    elseif Config.Framework == 'qb' then
        return exports['qb-core']:GetCoreObject()
    elseif Config.Framework == 'qbox' then
        return exports['qbx_core']:GetCoreObject()
    end
end

lib.callback.register('elevate_vehiclerental:pay', function(source, price)
    local src = source

    if Config.Framework == 'standalone' then
        return true
    end

    if Config.Framework == 'esx' then
        local ESX = getFramework()
        local xPlayer = ESX.GetPlayerFromId(src)

        local account = Config.PaymentType == 'bank' and 'bank' or 'money'
        if xPlayer.getAccount(account).money >= price then
            xPlayer.removeAccountMoney(account, price)
            return true
        end
    end

    if Config.Framework == 'qb' then
        local QB = getFramework()
        local Player = QB.Functions.GetPlayer(src)

        local account = Config.PaymentType == 'bank' and 'bank' or 'cash'
        if Player.Functions.GetMoney(account) >= price then
            Player.Functions.RemoveMoney(account, price)
            return true
        end
    end

    if Config.Framework == 'qbox' then
        local QBX = getFramework()
        local Player = QBX:GetPlayer(src)

        local account = Config.PaymentType == 'bank' and 'bank' or 'cash'
        if Player.Functions.GetMoney(account) >= price then
            Player.Functions.RemoveMoney(account, price)
            return true
        end
    end

    return false
end)
