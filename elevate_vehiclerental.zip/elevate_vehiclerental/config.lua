
Config = {}

-- FRAMEWORK: 'esx', 'qb', 'qbox', or 'standalone'
Config.Framework = 'standalone'

-- Payment type: 'bank' or 'cash'
Config.PaymentType = 'bank'
-- Ped Spawn Location: "vec4(-1034.6, -2733.6, 20.1, 330.0)"
Config.RentalPed = {
    model = 'a_m_m_business_01',
    coords = vec4(-1034.6, -2733.6, 20.1, 330.0)
}
-- Spawn Location for rented vehicles: "vec4(-1029.2, -2730.8, 20.1, 330.0)"
Config.SpawnPoint = vec4(-1029.2, -2730.8, 20.1, 330.0)
-- Blip settings for the rental location
Config.Blip = {
    sprite = 225,
    color = 3,
    scale = 0.8,
    label = 'Vehicle Rental'
}

-- Add unlimited custom vehicles here
Config.Vehicles = {
    { label = "Blista", model = "blista", price = 250 },
    { label = "Sultan RS", model = "sultanrs", price = 1500 },
    { label = "Adder", model = "adder", price = 5000 },
}
