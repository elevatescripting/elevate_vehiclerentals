
local function openRentalMenu()
    local options = {}

    for _, v in pairs(Config.Vehicles) do
        options[#options + 1] = {
            title = v.label,
            description = "Rent for $" .. v.price,
            icon = "car",
            onSelect = function()
                lib.callback('elevate_vehiclerental:pay', false, function(success)
                    if success then
                        rentVehicle(v.model)
                    else
                        lib.notify({
                            title = 'Rental',
                            description = 'Not enough money',
                            type = 'error'
                        })
                    end
                end, v.price)
            end
        }
    end

    lib.registerContext({
        id = 'elevate_vehiclerental_menu',
        title = 'Vehicle Rental',
        options = options
    })

    lib.showContext('elevate_vehiclerental_menu')
end

function rentVehicle(model)
    local ped = PlayerPedId()
    local coords = Config.SpawnPoint

    lib.requestModel(model)

    local vehicle = CreateVehicle(joaat(model), coords.x, coords.y, coords.z, coords.w, true, false)

    SetPedIntoVehicle(ped, vehicle, -1)
    SetVehicleEngineOn(vehicle, true, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)

    lib.notify({
        title = 'Rental',
        description = 'Vehicle rented successfully',
        type = 'success'
    })
end

CreateThread(function()

    local blip = AddBlipForCoord(Config.RentalPed.coords.x, Config.RentalPed.coords.y, Config.RentalPed.coords.z)
    SetBlipSprite(blip, Config.Blip.sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, Config.Blip.scale)
    SetBlipColour(blip, Config.Blip.color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.Blip.label)
    EndTextCommandSetBlipName(blip)

    lib.requestModel(Config.RentalPed.model)
    local ped = CreatePed(0, joaat(Config.RentalPed.model),
        Config.RentalPed.coords.x,
        Config.RentalPed.coords.y,
        Config.RentalPed.coords.z - 1.0,
        Config.RentalPed.coords.w,
        false, true)

    SetEntityInvincible(ped, true)
    FreezeEntityPosition(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    exports.ox_target:addLocalEntity(ped, {
        {
            label = 'Rent Vehicle',
            icon = 'fa-solid fa-car',
            onSelect = function()
                openRentalMenu()
            end
        }
    })
end)
